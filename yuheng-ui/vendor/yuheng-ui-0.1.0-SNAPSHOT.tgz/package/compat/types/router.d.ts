import type { RouteMeta, RouteRecordRaw } from 'vue-router'

/**
* redirect: noredirect        当设置 noredirect 的时候该路由在面包屑导航中不可被点击
* name:'router-name'          设定路由的名字，一定要填写不然使用<keep-alive>时会出现各种问题
* meta : {
    hidden: true              当设置 true 的时候该路由不会再侧边栏出现 如404，login等页面(默认 false)

    alwaysShow: true          当你一个路由下面的 children 声明的路由大于1个时，自动会变成嵌套的模式，
                              只有一个时，会将那个子路由当做根路由显示在侧边栏，
                              若你想不管路由下面的 children 声明的个数都显示你的根路由，
                              你可以设置 alwaysShow: true，这样它就会忽略之前定义的规则，
                              一直显示根路由(默认 false)

    title: 'title'            设置该路由在侧边栏和面包屑中展示的名字

    titleSuffix: '2'          当 path 和 title 重复时的后缀或备注

    icon: 'svg-name'          设置该路由的图标

    noCache: true             如果设置为true，则不会被 <keep-alive> 缓存(默认 false)

    viewKey: 'view-name'      设置稳定的页面实例标识，路由地址变化时复用同一个组件实例

    breadcrumb: false         如果设置为false，则不会在breadcrumb面包屑中显示(默认 true)

    affix: true               如果设置为true，则会一直固定在tag项中(默认 false)

    noTagsView: true          如果设置为true，则不会出现在tag中(默认 false)

    activeMenu: '/home'  显示高亮的路由路径

    followAuth: '/home'  跟随哪个路由进行权限过滤

    canTo: true               设置为true即使hidden为true，也依然可以进行路由跳转(默认 false)
  }
**/
declare module 'vue-router' {
  interface RouteMeta extends Record<string | number | symbol, unknown> {
    hidden?: boolean
    alwaysShow?: boolean
    title?: string
    titleSuffix?: string
    icon?: string
    noCache?: boolean
    viewKey?: string
    breadcrumb?: boolean
    affix?: boolean
    activeMenu?: string
    noTagsView?: boolean
    followAuth?: string
    canTo?: boolean
    hash?: string
    iframeSrc?: string
    link?: string
    params?: Recordable
    query?: Recordable
  }
}

/** Navigation records require the identity and metadata consumed by menu components. */
export interface NavigationRoute
  extends Omit<RouteRecordRaw, 'name' | 'meta' | 'children' | 'component' | 'components'> {
  name: string
  meta: RouteMeta
  component?: RouteRecordRaw['component'] | string
  components?: RouteRecordRaw['components']
  children?: NavigationRoute[]
  fullPath?: string
  keepAlive?: boolean
}

export interface BackendMenuRoute extends Omit<RouteRecordRaw, 'name' | 'meta' | 'children' | 'component'> {
  icon: string
  name: string
  meta: RouteMeta
  component: string
  componentName?: string
  id?: number | string
  path: string
  redirect: string
  children?: BackendMenuRoute[]
  keepAlive?: boolean
  visible?: boolean
  parentId?: number
  alwaysShow?: boolean
}

declare global {
  interface AppRouteRecordRaw extends NavigationRoute {}
  interface AppCustomRouteRecordRaw extends BackendMenuRoute {}
}
