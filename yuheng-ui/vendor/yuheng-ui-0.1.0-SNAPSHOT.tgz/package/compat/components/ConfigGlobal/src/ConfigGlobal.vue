<script setup lang="ts">
import { provide, computed, watch, onMounted } from 'vue'
import { propTypes } from '../../../utils/propTypes.ts'
import { ComponentSize, ElConfigProvider } from 'element-plus'
import { useLocaleStore } from '../../../store/modules/locale.ts'
import { useWindowSize } from '@vueuse/core'
import { useAppStore } from '../../../store/modules/app.ts'
import { setCssVar } from '../../../utils/index.ts'
import { useDesign } from '../../../hooks/web/useDesign.ts'
import { normalizeLayout } from '../../../utils/layout.ts'

const { variables } = useDesign()

const appStore = useAppStore()

const props = defineProps({
  size: propTypes.oneOf<ComponentSize>(['default', 'small', 'large']).def('default')
})

provide('configGlobal', props)

// 初始化所有主题色
onMounted(() => {
  appStore.setCssVarTheme()
})

const { width } = useWindowSize()

// 监听窗口变化
watch(
  () => width.value,
  (width: number) => {
    if (width < 768) {
      !appStore.getMobile ? appStore.setMobile(true) : undefined
      setCssVar('--left-menu-min-width', '0')
      appStore.setCollapse(true)
      normalizeLayout(appStore.getLayout) !== 'sidebar-nav'
        ? appStore.setLayout('sidebar-nav')
        : undefined
    } else {
      appStore.getMobile ? appStore.setMobile(false) : undefined
      setCssVar('--left-menu-min-width', '64px')
    }
  },
  {
    immediate: true
  }
)

// 多语言相关
const localeStore = useLocaleStore()

const currentLocale = computed(() => localeStore.currentLocale)
</script>

<template>
  <ElConfigProvider
    :namespace="variables.elNamespace"
    :locale="currentLocale.elLocale"
    :message="{ max: 5 }"
    :size="size"
  >
    <slot></slot>
  </ElConfigProvider>
</template>
